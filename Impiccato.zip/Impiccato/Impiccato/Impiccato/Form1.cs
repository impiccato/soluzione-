﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Impiccato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = imageList1.Images[0];
            Ricomincia();
        }

        string[] parola = new string[] {"CANE", "RONDINE", "CANGURO", "CASTORO", "CIAO"};
        string[] suggerimenti = new string[] {"Animale domestico", "Uccello migratore", "Marsupiale", "Mangia il legno", "Saluto" };

        string temp;
        string temp2;
        int posizione_parola;
        int errori = 1;

        private void Ricomincia()
        {
            Random a = new Random();
            int aCaso = a.Next(0, 5);

            temp = parola[aCaso];
            textBox2.Text = suggerimenti[aCaso];
            posizione_parola = aCaso;

            for (int x = 0; x < temp.Length; x++)
            {
                temp2 += "-";
            }
            textBox1.Text = temp2;
        }

        private void TrovaLettera(char lettera)
        {
            int temp4 = 0;
            for (int i = 0; i < parola[posizione_parola].Length; i++)
            {
                if (parola[posizione_parola][i] == lettera)
                {
                    StringBuilder temp3 = new StringBuilder(temp2);
                    temp3[i] = lettera;
                    temp2 = temp3.ToString();

                    textBox1.Text = temp2;

                    if (parola[posizione_parola] == textBox1.Text)
                    {
                        MessageBox.Show("Hai Vinto!");
                        GiocoReset();
                    }
                }
                else
                {
                    temp4++;
                }
            }

            if (temp4 == parola[posizione_parola].Length)
            {
                pictureBox1.Image = imageList1.Images[errori];
                errori++;

                if (errori == 7)
                {
                    MessageBox.Show("Hai perso!\nLa risposta corretta era:\n" + temp);
                    GiocoReset();
                }
            }
        }

        private void GiocoReset()
        {
            temp = "";
            temp2 = "";
            posizione_parola = 0;
            errori = 1;
            pictureBox1.Image = imageList1.Images[0];
            Ricomincia();

            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled = true;
            button11.Enabled = true;
            button12.Enabled = true;
            button13.Enabled = true;
            button14.Enabled = true;
            button15.Enabled = true;
            button16.Enabled = true;
            button17.Enabled = true;
            button18.Enabled = true;
            button19.Enabled = true;
            button20.Enabled = true;
            button21.Enabled = true;
            button22.Enabled = true;
            button23.Enabled = true;
            button24.Enabled = true;
            button25.Enabled = true;
            button26.Enabled = true;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            TrovaLettera('A');
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            TrovaLettera('B');
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.Enabled = false;
            TrovaLettera('C');
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.Enabled = false;
            TrovaLettera('D');
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.Enabled = false;
            TrovaLettera('E');
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button6.Enabled = false;
            TrovaLettera('F');
           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.Enabled = false;
            TrovaLettera('G');
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.Enabled = false;
            TrovaLettera('H');
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.Enabled = false;
            TrovaLettera('I');
            
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button10.Enabled = false;
            TrovaLettera('J');
           
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button11.Enabled = false;
            TrovaLettera('K');
            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button12.Enabled = false;
            TrovaLettera('L');
            
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button13.Enabled = false;
            TrovaLettera('M');
           
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button14.Enabled = false;
            TrovaLettera('N');
            
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button15.Enabled = false;
            TrovaLettera('O');
           
        }

        private void button16_Click(object sender, EventArgs e)
        {
            button16.Enabled = false;
            TrovaLettera('P');
            
        }

        private void button17_Click(object sender, EventArgs e)
        {
            button17.Enabled = false;
            TrovaLettera('Q');
            
        }

        private void button18_Click(object sender, EventArgs e)
        {
            button18.Enabled = false;
            TrovaLettera('R');
            
        }

        private void button19_Click(object sender, EventArgs e)
        {
            button19.Enabled = false;
            TrovaLettera('S');
           
        }

        private void button20_Click(object sender, EventArgs e)
        {
            button20.Enabled = false;
            TrovaLettera('T');
            
        }

        private void button21_Click(object sender, EventArgs e)
        {
            button21.Enabled = false;
            TrovaLettera('U');
            
        }

        private void button22_Click(object sender, EventArgs e)
        {
            button22.Enabled = false;
            TrovaLettera('V');
            
        }

        private void button23_Click(object sender, EventArgs e)
        {
            button23.Enabled = false;
            TrovaLettera('W');
            
        }

        private void button24_Click(object sender, EventArgs e)
        {
            button24.Enabled = false;
            TrovaLettera('X');
           
        }

        private void button25_Click(object sender, EventArgs e)
        {
            button25.Enabled = false;
            TrovaLettera('Y');
           
        }

        private void button26_Click(object sender, EventArgs e)
        {
            button26.Enabled = false;
            TrovaLettera('Z');
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
